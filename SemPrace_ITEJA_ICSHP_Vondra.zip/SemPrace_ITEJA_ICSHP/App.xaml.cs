﻿using System.Windows;

namespace SemPrace_ITEJA_ICSHP
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
