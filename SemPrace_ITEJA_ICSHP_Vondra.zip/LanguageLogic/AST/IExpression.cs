﻿namespace LanguageLogic.AST
{
    public interface IExpression : IASTNode
    {
    }
}
