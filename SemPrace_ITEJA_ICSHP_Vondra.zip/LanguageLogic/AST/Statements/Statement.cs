﻿namespace LanguageLogic.AST.Statements
{
    public interface IStatement : IASTNode
    {
    }
}